

class Service:
    ...