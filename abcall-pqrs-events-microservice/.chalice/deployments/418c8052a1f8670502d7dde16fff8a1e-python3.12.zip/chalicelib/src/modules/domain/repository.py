from abc import ABC
from chalicelib.src.seedwork.domain.repository import Repository


class IncidenceRepository(Repository, ABC):
    pass